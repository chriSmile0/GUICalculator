abstract class EXPR_UNARY extends EXPR {
	protected EXPR value;
}
