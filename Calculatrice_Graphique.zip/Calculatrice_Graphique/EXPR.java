abstract class EXPR {
	abstract double eval();
}



